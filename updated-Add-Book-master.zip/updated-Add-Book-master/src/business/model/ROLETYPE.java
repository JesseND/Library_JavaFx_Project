package business.model;

public enum ROLETYPE {

	ADMIN, LIBRARIAN, LIBRAY_MEMBER
}
