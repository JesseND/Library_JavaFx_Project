package business.model;

import java.io.Serializable;

public class Admin extends Role implements Serializable {

	public Admin() {
		super(ROLETYPE.ADMIN);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -5784940998950074244L;
	
	

}
