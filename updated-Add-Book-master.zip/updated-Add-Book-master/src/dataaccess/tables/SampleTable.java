package dataaccess.tables;

public class SampleTable {

}
