package dataaccess.dao;

public class SampleDao {

}
